このパッケージの説明は、以下のHTMLドキュメントを参照ください。

documents/index.html